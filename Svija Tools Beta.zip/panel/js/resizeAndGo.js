//:::::::::::::::::::::::::::::::::::::::: resizeAndGo.js

/*———————————————————————————————————————— notes

    this is used instead of direct links so we can resize
    the panel BEFORE chaning the link — it avoids an
    obvious flash and late resize
    
    something something */

//  javascript:openLink('more.html');
//  javascript:openLink('vibeBack');


//:::::::::::::::::::::::::::::::::::::::: functions

//:::::::::::::::::::::::::::::::::::::::: fin
